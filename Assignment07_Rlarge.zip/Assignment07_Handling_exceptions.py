while(True):
    try:
        name = str(input("Please enter a name: "))
        #if nothing is entered, or a value of less than 1, Syntax error is raised
        if len(name) < 1:
            raise SyntaxError
        break
    #Except will catch SyntaxErrors and can be configured to show customized errors.
    except SyntaxError:
        print("Syntax error: no value added. Please try again. ")
    #finally is always executed before leaving the try statement.
    finally:
        objfile = open("C:\\_PythonClass\Assignment07\Module07\\text.txt", "w")
        objfile.write(name)
        objfile.close()
        print("your input,", name, ",", "has been saved to a txt file, text.txt")


