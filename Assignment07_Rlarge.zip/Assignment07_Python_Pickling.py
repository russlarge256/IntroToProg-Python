import pickle

#simple example of how you can use python pickling.

def storeData():
    #initialize data to be stored
    student_1 = {"name": "james", "age": 25, "year": "junior"}
    student_2 = {"name": "rick", "age": 35, "year": "senior"}

    #create database
    #load student information
    database = {}
    database["student 1 info"] = student_1
    database["student 2 info"] = student_2

    # add data to the pickle dat file
    objfile = open("picklexample_1.dat", "wb")
    pickle.dump(database, objfile)
    objfile.close()

def loadData():
    #reading binary file
    objfile = open("picklexample_1.dat", "rb")
    database = pickle.load(objfile)
    for keys in database:
        #unpickle data and display information
        print(keys, "=", database[keys])
    objfile.close()

#run functions
storeData()
loadData()