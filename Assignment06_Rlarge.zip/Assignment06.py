#-------------------------------------------------------------------#
# Title: Working with Functions
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   RLarge, 11/26/2018, Modified script, organized script by
#   (cont) using functions
#------------------------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFileName = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strmenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# Set up class for functions

# Step 2
# Set up functions to:
# load current data
# Display a menu of choices to the user
# Add a new item to the list/Table
# Remove a new item to the list/Table
# Save tasks to the ToDo.txt file
# Display a menu of choices to the user

# Step 3
# Load data from txt file

# Step 4
# Execute functions based on user input


#------------------------------------------------------------------#

objFileName = "C:\_PythonClass\Assignment06\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

strmenu = ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)

# Step 1 & 2
# Create a new class and set up functions
class todo(object):
    """This class contains methods to execute menu options for the todo list homework"""
    @staticmethod
    def ShowCurrent():
        """This function displays current data within the text file"""
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        #return
    @staticmethod
    def AddValues():
        """This function requests new entries from the user, appends to the data,
         and displays the data"""
        if(strChoice.strip() == '2'):
            strTask = str(input("What is the task? - ")).strip()
            strPriority = str(input("What is the priority? [high|low] - ")).strip()
            dicRow = {"Task": strTask, "Priority": strPriority}
            lstTable.append(dicRow)

            #4a Show the current items in the table
            print("******* The current items ToDo are: *******")
            for row in lstTable:
                print(row["Task"] + "," + row["Priority"] + ",")
            print("*******************************************")
            return
    @staticmethod
    def RemoveValues():
        """This function removes a task by request from the user, and displays the data"""
        # 5a-Allow user to indicate which row to delete
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

        # 5c Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        return
    @staticmethod
    def SaveData():
        """This function saves all data added/removed to the txt file by request from user"""
        # 5a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        # 5b Ask if they want save that data
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
        return

# Step 3
# Load data from txt file
#todo.Loadtxt()
objFile = open(objFileName, "r")
for line in objFile:
    strData = line.split(",") # readline() reads a line of the data into 2 elements
    dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
    lstTable.append(dicRow)
objFile.close()

# Step 4
# Execute functions based on user input
while(True):
    print(strmenu)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))

    if (strChoice.strip() == '1'):
        todo.ShowCurrent()
        continue
    elif (strChoice.strip() == '2'):
        todo.AddValues()
        continue
    elif (strChoice.strip() == '3'):
        todo.RemoveValues()
        continue
    elif (strChoice.strip() == '4'):
        todo.SaveData()
        continue
    elif (strChoice.strip() == '5'):
        break




